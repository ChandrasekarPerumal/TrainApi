package com.train.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainTrackingApplication.class, args);
	}

}
